CREATE OR ALTER TRIGGER TriggerLogAltProducao
ON Producao
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    DECLARE @Acao VARCHAR(10);
    DECLARE @Descricao VARCHAR(100);
    DECLARE @DataHora DATETIME = GETDATE();
    DECLARE @ID INT;
    DECLARE @Tabela VARCHAR(50) = 'Producao';

    -- Verificar a a��o realizada (INSERT, UPDATE, DELETE)
    IF EXISTS (SELECT * FROM inserted)
    BEGIN
        IF EXISTS (SELECT * FROM deleted)
            SET @Acao = 'UPDATE';
        ELSE
            SET @Acao = 'INSERT';
    END
    ELSE
        SET @Acao = 'DELETE';

    -- Capturar o ID da Produ��o afetada
   IF @Acao IN ('INSERT', 'UPDATE')
        SET @ID = (SELECT producao_id FROM inserted);
    ELSE IF @Acao = 'DELETE'
        SET @ID = (SELECT producao_id FROM deleted);

    -- Montar a descri��o da altera��o
    IF @Acao = 'INSERT'
        SET @Descricao = 'Inserida nova produ��o.';
    ELSE IF @Acao = 'UPDATE'
        SET @Descricao = 'Atualizada produ��o.';
    ELSE IF @Acao = 'DELETE'
        SET @Descricao = 'Exclu�da produ��o.';

    -- Registrar a altera��o na tabela de log
    INSERT INTO Log_Alt (Acao, Tabela, Descricao, DataHora, Id)
    VALUES (@Acao, @Tabela, @Descricao, @DataHora, @ID);
END;

-- TRIGGER para registrar altera��es na tabela de Mat�ria-Prima
CREATE or alter TRIGGER LogAlteracoesMP
ON Materia_Prima		
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    DECLARE @Acao VARCHAR(10);
    DECLARE @Descricao VARCHAR(100);
    DECLARE @DataHora DATETIME = GETDATE();
    DECLARE @ID INT;
    DECLARE @Tabela VARCHAR(50) = 'Materia_Prima';

    -- Verificar a a��o realizada (INSERT, UPDATE, DELETE)
    IF EXISTS (SELECT * FROM inserted)
    BEGIN
        IF EXISTS (SELECT * FROM deleted)
            SET @Acao = 'UPDATE';
        ELSE
            SET @Acao = 'INSERT';
    END
    ELSE
        SET @Acao = 'DELETE';

    -- Capturar o ID da Mat�ria-Prima afetada
    IF @Acao = 'INSERT'
        SET @ID = SCOPE_IDENTITY();
    ELSE IF @Acao = 'UPDATE'
        SET @ID = (SELECT materia_prima_ID FROM inserted);
    ELSE IF @Acao = 'DELETE'
        SET @ID = (SELECT materia_prima_ID FROM deleted);

    -- Montar a descri��o da altera��o
    IF @Acao = 'INSERT'
        SET @Descricao = 'Inserida nova Mat�ria-Prima.';
    ELSE IF @Acao = 'UPDATE'
        SET @Descricao = 'Atualizada Mat�ria-Prima.';
    ELSE IF @Acao = 'DELETE'
        SET @Descricao = 'Exclu�da Mat�ria-Prima.';

    -- Registrar a altera��o na tabela de log
    INSERT INTO Log_Alt (Acao, Tabela, Descricao, DataHora, Id)
    VALUES (@Acao, @Tabela, @Descricao, @DataHora, @ID);
END;

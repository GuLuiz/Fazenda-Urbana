CREATE OR Alter TRIGGER TriggerLogAlt
ON Fornecedores
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    DECLARE @Acao VARCHAR(10);
    DECLARE @Tabela VARCHAR(10) = 'Fornecedores';
    DECLARE @Descricao VARCHAR(100);
    DECLARE @DataHora DATETIME = GETDATE();
    DECLARE @ID INT;

    -- Verificar a a��o realizada (INSERT, UPDATE, DELETE)
    IF EXISTS (SELECT * FROM inserted)
    BEGIN
        IF EXISTS (SELECT * FROM deleted)
            SET @Acao = 'UPDATE';
        ELSE
            SET @Acao = 'INSERT';
    END
    ELSE
        SET @Acao = 'DELETE';

    -- Capturar o ID do fornecedor afetado
    IF @Acao = 'INSERT'
        SET @ID = SCOPE_IDENTITY();
    ELSE IF @Acao = 'UPDATE'
        SET @ID = (SELECT fornecedor_ID FROM inserted);
    ELSE IF @Acao = 'DELETE'
        SET @ID = (SELECT fornecedor_ID FROM deleted);

    -- Montar a descri��o da altera��o
    IF @Acao = 'INSERT'
        SET @Descricao = 'Inserido novo fornecedor.';
    ELSE IF @Acao = 'UPDATE'
        SET @Descricao = 'Atualizado fornecedor.';
    ELSE IF @Acao = 'DELETE'
        SET @Descricao = 'Exclu�do fornecedor.';

    -- Registrar a altera��o na tabela de log
    INSERT INTO Log_Alt (Acao, Tabela, Descricao, DataHora, Id)
    VALUES (@Acao, @Tabela, @Descricao, @DataHora, @ID);
END;
